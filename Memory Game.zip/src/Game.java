import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
public class Game extends JFrame
{
	int count = 0;
	String control = "";
	String a = "D:\\Toshiba\\ECLIPSE JAVA\\workspace\\Memory Game\\src\\a.png";
	String b = "D:\\Toshiba\\ECLIPSE JAVA\\workspace\\Memory Game\\src\\b.png";
	String c = "D:\\Toshiba\\ECLIPSE JAVA\\workspace\\Memory Game\\src\\c.png";
	String d = "D:\\Toshiba\\ECLIPSE JAVA\\workspace\\Memory Game\\src\\d.png";
	String e = "D:\\Toshiba\\ECLIPSE JAVA\\workspace\\Memory Game\\src\\e.png";

	private JPanel panel = new JPanel(new GridLayout(5,3));
	
	private ImageIcon icon1 = new ImageIcon(a);
	private ImageIcon icon2 = new ImageIcon(b);
	private ImageIcon icon3 = new ImageIcon(c);
	private ImageIcon icon4 = new ImageIcon(d);
	private ImageIcon icon5 = new ImageIcon(e);
	
	private JButton button1 = new JButton();
	private JButton button2 = new JButton();
	private JButton button3 = new JButton();
	private JButton button4 = new JButton();
	private JButton button5 = new JButton();
	private JButton button6 = new JButton();
	private JButton button7 = new JButton();
	private JButton button8 = new JButton();
	private JButton button9 = new JButton();
	private JButton button10 = new JButton();
	
	private JLabel label = new JLabel("");

	ButtonListener listener = new ButtonListener();
	public Game()
	{
		panel.add(button1);
		panel.add(button2);
		panel.add(button3);
		panel.add(button4);
		panel.add(button5);
		panel.add(button6);
		panel.add(button7);
		panel.add(button8);
		panel.add(button9);
		panel.add(button10);
		
		panel.add(label);

		button1.addActionListener(listener);
		button2.addActionListener(listener);
		button3.addActionListener(listener);
		button4.addActionListener(listener);
		button5.addActionListener(listener);
		button6.addActionListener(listener);
		button7.addActionListener(listener);
		button8.addActionListener(listener);
		button9.addActionListener(listener);
		button10.addActionListener(listener);

		this.setContentPane(panel);
		this.setSize(400,300);
		this.setVisible(true);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	class ButtonListener implements ActionListener
	{	
		public void actionPerformed(ActionEvent e)
		{	
			if (count < 2)
			{
				if(e.getSource() == button1)
				{
		    		button1.setIcon(icon1);
		    		count++;
		    		control += "�";
				}
				if(e.getSource() == button2)
				{
		    		button2.setIcon(icon2);
		    		count++;
		    		control += "�";
				}
				if(e.getSource() == button3)
				{
		    		button3.setIcon(icon3);
		    		count++;
		    		control += "�";
				}
				if(e.getSource() == button4)
				{
		    		button4.setIcon(icon4);
		    		count++;
		    		control += "�";
				}
				if(e.getSource() == button5)
				{
		    		button5.setIcon(icon5);
		    		count++;
		    		control += "�";
				}
				if(e.getSource() == button6)
				{
		    		button6.setIcon(icon1);
		    		count++;
		    		control += "�";
				}
				if(e.getSource() == button7)
				{
		    		button7.setIcon(icon2);
		    		count++;
		    		control += "�";
				}
				if(e.getSource() == button8)
				{
		    		button8.setIcon(icon3);
		    		count++;
		    		control += "�";
				}
				if(e.getSource() == button9)
				{
		    		button9.setIcon(icon4);
		    		count++;
		    		control += "�";
				}
				if(e.getSource() == button10)
				{
		    		button10.setIcon(icon5);
		    		count++;
		    		control += "�";
				}
			}
			if (count==2)
			{
				if(control.charAt(0)==control.charAt(1))
				{
					System.out.println(control.charAt(0)==control.charAt(1));
		    		label.setText("�����");
				}
				else
				{
					System.out.println(control.charAt(0)==control.charAt(1));
		    		label.setText("�����");		
				}
			}
		}
	}
}