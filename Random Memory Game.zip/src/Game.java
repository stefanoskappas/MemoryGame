import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.Random;
public class Game extends JFrame
{
	Random r = new Random();
	String control = "";
	int id1, id2, i = 0, index, count = 0;
	int [] aray = new int[10];
	
	//String a = "D:\\Toshiba\\ECLIPSE JAVA\\workspace\\Memory Game\\src\\a.png";
	//String b = "D:\\Toshiba\\ECLIPSE JAVA\\workspace\\Memory Game\\src\\b.png";
	//String c = "D:\\Toshiba\\ECLIPSE JAVA\\workspace\\Memory Game\\src\\c.png";
	//String d = "D:\\Toshiba\\ECLIPSE JAVA\\workspace\\Memory Game\\src\\d.png";
	//String e = "D:\\Toshiba\\ECLIPSE JAVA\\workspace\\Memory Game\\src\\e.png";
	String a = "D:\\Toshiba\\ECLIPSE JAVA\\workspace\\Memory Game\\src\\fpack.png";
	String b = "D:\\Toshiba\\ECLIPSE JAVA\\workspace\\Memory Game\\src\\b.png";
	String c = "D:\\Toshiba\\ECLIPSE JAVA\\workspace\\Memory Game\\src\\c.png";
	String d = "D:\\Toshiba\\ECLIPSE JAVA\\workspace\\Memory Game\\src\\d.png";
	String e = "D:\\Toshiba\\ECLIPSE JAVA\\workspace\\Memory Game\\src\\e.png";

	private JPanel panel = new JPanel(new GridLayout(6,2));
	
	private ImageIcon icon1 = new ImageIcon(a);
	private ImageIcon icon2 = new ImageIcon(b);
	private ImageIcon icon3 = new ImageIcon(c);
	private ImageIcon icon4 = new ImageIcon(d);
	private ImageIcon icon5 = new ImageIcon(e);	

	private JButton button1 = new JButton();
	private JButton button2 = new JButton();
	private JButton button3 = new JButton();
	private JButton button4 = new JButton();
	private JButton button5 = new JButton();
	private JButton button6 = new JButton();
	private JButton button7 = new JButton();
	private JButton button8 = new JButton();
	private JButton button9 = new JButton();
	private JButton button10 = new JButton();
	
	private JLabel label = new JLabel("", SwingConstants.CENTER);

	ButtonListener listener = new ButtonListener();
	
	void addButton(int index)
	{
		if (index == 1)
			panel.add(button1);
		if (index == 2)
			panel.add(button2);
		if (index == 3)
			panel.add(button3);
		if (index == 4)
			panel.add(button4);
		if (index == 5)
			panel.add(button5);
		if (index == 6)
			panel.add(button6);
		if (index == 7)
			panel.add(button7);
		if (index == 8)
			panel.add(button8);
		if (index == 9)
			panel.add(button9);
		if (index == 10)
			panel.add(button10);
	}
	void random()
	{
		while(i < 10)
		{
			int row = 0;
			if (i == 0)
			{
				aray[i] = r.nextInt(10);
			}
			if (i > 0)
			{
				index = r.nextInt(10);
				for (row = 0; row < i; row++)
				{
					if (index == aray[row])
					{
						index = r.nextInt(10);
						row = -1;
					}
				}
				aray[i] = index;	
			}
			i++;
		}
	}
	public Game()
	{
		random();
		for(int i=0; i<10; i++)
			addButton(aray[i]+1);
		
		panel.add(label);

		button1.addActionListener(listener);
		button2.addActionListener(listener);
		button3.addActionListener(listener);
		button4.addActionListener(listener);
		button5.addActionListener(listener);
		button6.addActionListener(listener);
		button7.addActionListener(listener);
		button8.addActionListener(listener);
		button9.addActionListener(listener);
		button10.addActionListener(listener);

		this.setContentPane(panel);
		this.setSize(400,300);
		this.setVisible(true);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	
	class ButtonListener implements ActionListener
	{	
		public void actionPerformed(ActionEvent e)
		{	
			if (count < 2)
			{
	    		label.setText("");
				if(e.getSource() == button1)
				{
		    		button1.setIcon(icon1);
		    		if (count == 0)
		    			id1 = 1;
		    		else
		    			id2 = 1;
		    		count++;
		    		control += "�";
				}
				if(e.getSource() == button2)
				{
		    		button2.setIcon(icon2);
		    		if (count == 0)
		    			id1 = 2;
		    		else
		    			id2 = 2;
		    		count++;
		    		control += "�";
				}
				if(e.getSource() == button3)
				{
		    		button3.setIcon(icon3);
		    		if (count == 0)
		    			id1 = 3;
		    		else
		    			id2 = 3;
		    		count++;
		    		control += "�";
				}
				if(e.getSource() == button4)
				{
		    		button4.setIcon(icon4);
		    		if (count == 0)
		    			id1 = 4;
		    		else
		    			id2 = 4;
		    		count++;
		    		control += "�";
				}
				if(e.getSource() == button5)
				{
		    		button5.setIcon(icon5);
		    		if (count == 0)
		    			id1 = 5;
		    		else
		    			id2 = 5;
		    		count++;
		    		control += "�";
				}
				if(e.getSource() == button6)
				{
		    		button6.setIcon(icon1);
		    		if (count == 0)
		    			id1 = 6;
		    		else
		    			id2 = 6;
		    		count++;
		    		control += "�";
				}
				if(e.getSource() == button7)
				{
		    		button7.setIcon(icon2);
		    		if (count == 0)
		    			id1 = 7;
		    		else
		    			id2 = 7;
		    		count++;
		    		control += "�";
				}
				if(e.getSource() == button8)
				{
		    		button8.setIcon(icon3);
		    		if (count == 0)
		    			id1 = 8;
		    		else
		    			id2 = 8;
		    		count++;
		    		control += "�";
				}
				if(e.getSource() == button9)
				{
		    		button9.setIcon(icon4);
		    		if (count == 0)
		    			id1 = 9;
		    		else
		    			id2 = 9;
		    		count++;
		    		control += "�";
				}
				if(e.getSource() == button10)
				{
		    		button10.setIcon(icon5);
		    		if (count == 0)
		    			id1 = 10;
		    		else
		    			id2 = 10;
		    		count++;
		    		control += "�";
				}
			}
			if (count==2)
			{
				if(control.charAt(0)==control.charAt(1))
				{
		    		label.setText("�����");
		    		if (control.charAt(0) == '�')
		    		{
			    		button1.setBackground(Color.GREEN);
			    		button6.setBackground(Color.GREEN);
		    		}
		    		if (control.charAt(0) == '�')
		    		{
			    		button2.setBackground(Color.GREEN);
			    		button7.setBackground(Color.GREEN);
		    		}		    		
		    		if (control.charAt(0) == '�')
		    		{
			    		button3.setBackground(Color.GREEN);
			    		button8.setBackground(Color.GREEN);
		    		}		    		
		    		if (control.charAt(0) == '�')
		    		{
			    		button4.setBackground(Color.GREEN);
			    		button9.setBackground(Color.GREEN);
		    		}		    		
		    		if (control.charAt(0) == '�')
		    		{
			    		button5.setBackground(Color.GREEN);
			    		button10.setBackground(Color.GREEN);
		    		}
		    		count = 0;
		    		control = "";
				}
				else
				{
		    		label.setText("�����");
		    		if (id1 == 1)
		    			button1.setBackground(Color.RED);
		    		if (id1 == 2)
		    			button2.setBackground(Color.RED);
		    		if (id1 == 3)
		    			button3.setBackground(Color.RED);
		    		if (id1 == 4)
		    			button4.setBackground(Color.RED);
		    		if (id1 == 5)
		    			button5.setBackground(Color.RED);
		    		if (id1 == 6)
		    			button6.setBackground(Color.RED);
		    		if (id1 == 7)
		    			button7.setBackground(Color.RED);
		    		if (id1 == 8)
		    			button8.setBackground(Color.RED);
		    		if (id1 == 9)
		    			button9.setBackground(Color.RED);
		    		if (id1 == 10)
		    			button10.setBackground(Color.RED);
		    		if (id2 == 1)
		    			button1.setBackground(Color.RED);
		    		if (id2 == 2)
		    			button2.setBackground(Color.RED);
		    		if (id2 == 3)
		    			button3.setBackground(Color.RED);
		    		if (id2 == 4)
		    			button4.setBackground(Color.RED);
		    		if (id2 == 5)
		    			button5.setBackground(Color.RED);
		    		if (id2 == 6)
		    			button6.setBackground(Color.RED);
		    		if (id2 == 7)
		    			button7.setBackground(Color.RED);
		    		if (id2 == 8)
		    			button8.setBackground(Color.RED);
		    		if (id2 == 9)
		    			button9.setBackground(Color.RED);
		    		if (id2 == 10)
		    			button10.setBackground(Color.RED);
		    		count = 0;
		    		control = "";
				}
			}
		}
	}
}